//
//  ViewController.h
//  XLFoldClockDemo
//
//  Created by MengXianLiang on 2018/5/28.
//  Copyright © 2018年 mxl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

